from django.apps import AppConfig


class WebRequestLogsConfig(AppConfig):
    name = 'web_analytics'
